function deprecation_warning(string, block)

cwarndlg(string, 'casper deprecation warning', ['casper:',block,'_deprecation'], 'once');

