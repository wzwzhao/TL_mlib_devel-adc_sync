function gtkStartFcn()
evalin('base','clear gtk_*');